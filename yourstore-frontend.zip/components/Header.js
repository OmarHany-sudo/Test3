import Link from 'next/link'
export default function Header(){ return <header className="py-4"><div className="max-w-4xl mx-auto">YourStore Header</div></header> }
