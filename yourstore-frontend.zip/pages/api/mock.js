import mock from '../../data/mock-shop.json'
export default function handler(req,res){res.status(200).json(mock)}