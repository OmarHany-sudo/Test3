Railway Deployment (notes)
- Create a new project on Railway.
- Add a Postgres plugin (or use Railway's built-in PG).
- Set environment variables (see .env.example).
- Deploy the repository; set the build command to `npm install && npm run build` and start to `npm start`.
